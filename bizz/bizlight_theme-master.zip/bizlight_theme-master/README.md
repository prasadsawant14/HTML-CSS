# BizLight Theme

A custom Twitter Bootstrap theme that uses Sass. This project goes with this [YouTube tutorial](https://www.youtube.com/watch?v=pB7EwxwSfVk&feature=youtu.be). Feel free to do what you want with it

### Version
1.0.0
